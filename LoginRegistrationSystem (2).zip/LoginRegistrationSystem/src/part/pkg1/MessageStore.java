/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg1;

/**
 *
 * @author RC_Student_Lab
 */
/*
 MessageStore.java
 Manages storage and retrieval of Message objects for QuickChat.
*/

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MessageStore {
    private static final String FILE_NAME = "messages.txt";
    private static List<Message> messages = new ArrayList<>();
    private static int sequenceCounter = 1;

    // Add message to list
    public static void addMessage(Message m) {
        messages.add(m);
        saveToFile();
    }

    // Return next sequence number
    public static int getNextSeq() {
        return sequenceCounter++;
    }

    // Return total number of messages
    public static int returnTotalMessages() {
        return messages.size();
    }

    // Save all messages to file
    public static void saveToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Message m : messages) {
                bw.write(m.toString());
                bw.write("------------------------------------\n");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage());
        }
    }

    // Load messages from file (best effort)
    public static void loadFromFile() {
        File f = new File(FILE_NAME);
        if (!f.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");
            }
            // Display previously saved messages (optional)
            if (sb.length() > 0) {
                JOptionPane.showMessageDialog(null,
                        "Previously saved messages loaded from file.",
                        "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file: " + e.getMessage());
        }
    }

    // Show all messages in a dialog box
    public static void showMessagesDialog() {
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages recorded yet.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (Message m : messages) {
            sb.append(m.toString()).append("\n");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(500, 300));

        JOptionPane.showMessageDialog(null, scrollPane, "All Messages", JOptionPane.INFORMATION_MESSAGE);
    }
}