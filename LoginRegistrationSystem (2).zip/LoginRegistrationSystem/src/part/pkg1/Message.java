package part.pkg1;

import javax.swing.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

/**
 * Message.java
 * Defines a Message class for the QuickChat application.
 * Handles validation, ID generation, and message hashing.
 * @author RC_Student_Lab
 */
public class Message {
    private String messageID;       // 10-digit random ID
    private int seqNum;             // Sequential message number
    private String recipient;       // Cell number (+27...)
    private String messageText;     // Text message
    private String messageHash;     // SHA-256 hash of message text

    // Constructor
    public Message(int seqNum, String recipient, String messageText) {
        this.seqNum = seqNum;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = computeHash(messageText);
    }

    // Generate a random 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        long num = 1000000000L + (long)(rand.nextDouble() * 8999999999L);
        return String.valueOf(num);
    }

    // Validate Message ID (should be 10 digits)
    public boolean checkMessageID() {
        return messageID != null && messageID.length() == 10 && messageID.matches("\\d+");
    }

    // Validate recipient cell number
    // Returns 1 if valid, 0 if invalid
    public int checkRecipientCell() {
        if (recipient == null) return 0;
        // Must start with + and have 11–15 digits
        if (recipient.matches("\\+\\d{11,15}")) {
            return 1;
        }
        return 0;
    }

    // Compute SHA-256 hash of the message text
    private String computeHash(String text) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(text.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return "HASH_ERROR";
        }
    }

    // Get message hash
    public String getMessageHash() {
        return messageHash;
    }

    // Ask user what to do with message
    public String sentMessage() {
        String[] options = {"Send", "Store", "Discard"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "What would you like to do with this message?\n\n"
                        + "Recipient: " + recipient + "\nMessage: " + messageText,
                "Message Options",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );
        switch (choice) {
            case 0: return "send";
            case 1: return "store";
            default: return "discard";
        }
    }

    // String representation for display
    @Override
    public String toString() {
        return "Message #" + seqNum + "\n"
                + "ID: " + messageID + "\n"
                + "Recipient: " + recipient + "\n"
                + "Text: " + messageText + "\n"
                + "Hash: " + messageHash + "\n";
    }

    public Object printFullDetails() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // ========== TEST-SPECIFIC METHODS ==========
    // These methods return exact strings needed for unit testing
    
    /**
     * Test Method 1: Validate message length (max 250 characters)
     * @return "Message ready to send." if valid, error message if too long
     */
    public String validateMessageLength() {
        if (messageText == null || messageText.length() > 250) {
            return "Message exceeds 250 character limit.";
        }
        return "Message ready to send.";
    }

    /**
     * Test Method 2: Validate recipient phone format
     * @return "Cell phone number successfully captured." if valid format
     */
    public String validateRecipientFormat() {
        if (checkRecipientCell() == 1) {
            return "Cell phone number successfully captured.";
        }
        return "Invalid cell phone number format.";
    }

    /**
     * Test Method 3: Generate message hash in format FirstWord:MessageNum:LASTWORD
     * @return Formatted hash string
     */
    public String generateFormattedHash() {
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 0 ? words[words.length - 1] : "";
        
        return firstWord + ":" + seqNum + ":" + lastWord.toUpperCase();
    }

    /**
     * Test Method 4: Verify message ID format (10 digits)
     * @return The 10-digit message ID
     */
    public String getMessageID() {
        return messageID;
    }

    /**
     * Test Method 5: Process message action (Send/Store/Discard)
     * @param action The action to perform ("send", "store", "discard")
     * @return Status message based on action
     */
    public String processMessageAction(String action) {
        if (action == null) {
            return "Press 0 to delete message.";
        }
        
        switch (action.toLowerCase()) {
            case "send":
                return "Message successfully sent.";
            case "store":
                return "Message successfully stored.";
            case "discard":
                return "Press 0 to delete message.";
            default:
                return "Press 0 to delete message.";
        }
    }

    // Getter methods for testing
    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public int getSeqNum() {
        return seqNum;
    }
}