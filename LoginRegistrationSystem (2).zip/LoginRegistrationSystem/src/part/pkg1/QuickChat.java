/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg1;

/**
 *
 * @author RC_Student_Lab
 */
import javax.swing.*;
import java.util.HashMap;

// Assuming these classes exist: User, RegistrationFrame, Message, MessageStore
// If not, you'll need to implement them as stubs or fully.

public class QuickChat {
    private static final String REQUIRED_LOGIN = "gracegiftmonnatlala12-max";
    private static final String WELCOME_TEXT = "Welcome to QuickChat";

    public static void main(String[] args) {
        // Load messages as in Part 1
        MessageStore.loadFromFile();

        // Part 1: Login logic
        String login = JOptionPane.showInputDialog(null,
                "Enter your login username to continue:",
                "Login", JOptionPane.QUESTION_MESSAGE);

        if (login == null || !login.equals(REQUIRED_LOGIN)) {
            JOptionPane.showMessageDialog(null,
                    "Login failed. Exiting application.",
                    "Access Denied", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }

        JOptionPane.showMessageDialog(null, WELCOME_TEXT, "Welcome", JOptionPane.INFORMATION_MESSAGE);

        // Now, transition to Part 2's main logic after successful login
        SwingUtilities.invokeLater(() -> {
            HashMap<String, User> users = new HashMap<>();
            RegistrationFrame registrationFrame = new RegistrationFrame(users);
            registrationFrame.setVisible(true);
            // After the RegistrationFrame is closed, you can add code here to continue with Part 1 logic
            // For example, call a method to handle the rest of Part 1
            continuePart1Logic();
        });
    }

    // Helper method to continue with Part 1's original logic after Part 2
    private static void continuePart1Logic() {
        int maxMessages = 0;
        while (true) {
            String input = JOptionPane.showInputDialog(null,
                    "How many messages would you like to send this session? Enter a number (e.g., 2):",
                    "Number of messages", JOptionPane.QUESTION_MESSAGE);
            if (input == null) System.exit(0);
            try {
                maxMessages = Integer.parseInt(input.trim());
                if (maxMessages > 0) break;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid integer.");
            }
        }

        int sentCount = 0;
        boolean running = true;

        while (running) {
            String[] menuOptions = {"Send Message(s)", "Show Recently Sent (Coming Soon)", "Quit"};
            int choice = JOptionPane.showOptionDialog(null,
                    "Select an option:",
                    "Main Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    menuOptions,
                    menuOptions[0]);

            if (choice == 0) {
                if (sentCount >= maxMessages) {
                    JOptionPane.showMessageDialog(null, "Message limit reached for this session.");
                    continue;
                }

                String recipient = JOptionPane.showInputDialog(null,
                        "Enter recipient cell number (e.g., +27712345678):",
                        "Recipient", JOptionPane.QUESTION_MESSAGE);
                if (recipient == null) continue;

                String messageText = JOptionPane.showInputDialog(null,
                        "Enter message text (max 250 characters):",
                        "Compose Message", JOptionPane.PLAIN_MESSAGE);
                if (messageText == null || messageText.isEmpty()) continue;

                if (messageText.length() > 250) {
                    JOptionPane.showMessageDialog(null, "Message too long. Max 250 characters.");
                    continue;
                }

                int seq = MessageStore.getNextSeq();
                Message m = new Message(seq, recipient, messageText);

                if (!m.checkMessageID() || m.checkRecipientCell() == 0) {
                    JOptionPane.showMessageDialog(null, "Invalid message details.");
                    continue;
                }

                JOptionPane.showMessageDialog(null, "Message Hash: " + m.getMessageHash());

                String action = m.sentMessage();
                if ("send".equalsIgnoreCase(action) || "store".equalsIgnoreCase(action)) {
                    MessageStore.addMessage(m);
                    sentCount++;
                    JOptionPane.showMessageDialog(null, "Message recorded successfully.");
                    
                    // New code to show ID, Hash, Message, and Phone Number
                    JOptionPane.showMessageDialog(null,
                        "Message Details:\n" +
                        "ID: " + seq + "\n" +
                        "Hash: " + m.getMessageHash() + "\n" +
                        "Message: " + messageText + "\n" +
                        "Phone Number: " + recipient,
                        "Message Confirmation",
                        JOptionPane.INFORMATION_MESSAGE
                    );
                } else {
                    JOptionPane.showMessageDialog(null, "Message discarded.");
                }

            } else if (choice == 1) {
                JOptionPane.showMessageDialog(null, "Coming soon!");
            } else {
                int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to quit?");
                if (confirm == JOptionPane.YES_OPTION) running = false;
            }
        }

        MessageStore.showMessagesDialog();
        JOptionPane.showMessageDialog(null,
                "Total messages recorded: " + MessageStore.returnTotalMessages(),
                "Summary", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);  // End the application
    }
}


    
