import javax.swing.*;
import java.util.HashMap;
import part.pkg1.RegistrationFrame;
import part.pkg1.User;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Create a shared user list
            HashMap<String, User> users = new HashMap<>();

            // Start the registration frame
            RegistrationFrame registrationFrame = new RegistrationFrame(users);
            registrationFrame.setVisible(true);

            // When registration is done, user can move to login or chat
            // You can add this if your LoginFrame or QuickChat should follow after registration.
            // Example:
            // LoginFrame loginFrame = new LoginFrame(users);
            // loginFrame.setVisible(true);
        });
    }
}
