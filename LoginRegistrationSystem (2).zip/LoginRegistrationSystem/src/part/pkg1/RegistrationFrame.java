package part.pkg1;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.regex.Pattern;

public class RegistrationFrame extends JFrame {
    private final HashMap<String, User> users;
    private JTextField regUsernameField;
    private JPasswordField regPasswordField;
    private JTextField regCellphoneField;
    private JButton regRegisterButton;
    private JButton regLoginButton;
    private final Color SHOCKING_GREEN = new Color(57, 255, 20);

    public RegistrationFrame(HashMap<String, User> users) {
        this.users = users;
        initializeUI();
    }

    private void initializeUI() {
        setTitle("Registration");
        setSize(420, 380);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(SHOCKING_GREEN);
        panel.setLayout(null);

        // Title
        JLabel titleLabel = new JLabel("Register");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setBounds(150, 15, 150, 35);
        panel.add(titleLabel);

        // Username
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.BLACK);
        usernameLabel.setBounds(50, 70, 100, 25);
        panel.add(usernameLabel);

        regUsernameField = new JTextField();
        regUsernameField.setBounds(160, 70, 180, 25);
        panel.add(regUsernameField);

        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.BLACK);
        passwordLabel.setBounds(50, 110, 100, 25);
        panel.add(passwordLabel);

        regPasswordField = new JPasswordField();
        regPasswordField.setBounds(160, 110, 180, 25);
        panel.add(regPasswordField);

        // Cellphone
        JLabel cellphoneLabel = new JLabel("Cellphone:");
        cellphoneLabel.setForeground(Color.BLACK);
        cellphoneLabel.setBounds(50, 150, 100, 25);
        panel.add(cellphoneLabel);

        regCellphoneField = new JTextField();
        regCellphoneField.setBounds(160, 150, 180, 25);
        panel.add(regCellphoneField);

        // Buttons
        regRegisterButton = new JButton("Register");
        regRegisterButton.setBounds(160, 200, 100, 30);
        regRegisterButton.setBackground(Color.BLACK);
        regRegisterButton.setForeground(SHOCKING_GREEN);
        regRegisterButton.setFocusPainted(false);
        panel.add(regRegisterButton);

        regLoginButton = new JButton("Already Registered? Login");
        regLoginButton.setBounds(110, 245, 200, 30);
        regLoginButton.setBackground(Color.BLACK);
        regLoginButton.setForeground(SHOCKING_GREEN);
        regLoginButton.setFocusPainted(false);
        panel.add(regLoginButton);

        // Event listeners
        regRegisterButton.addActionListener(e -> handleRegistration());
        regLoginButton.addActionListener(e -> navigateToLogin());

        add(panel);
    }

    private void handleRegistration() {
        String username = regUsernameField.getText().trim();
        String password = new String(regPasswordField.getPassword());
        String cellphone = regCellphoneField.getText().trim();

        if (!validateUsername(username)) {
            showError("Username must contain an underscore and be no more than 5 characters long.", "Invalid Username");
            return;
        }

        if (!validatePassword(password)) {
            showError("Password must be at least 8 characters long, contain a capital letter, a number, and a special character.", "Invalid Password");
            return;
        }

        if (!validateCellphone(cellphone)) {
            showError("Cellphone must start with international country code (e.g. +1) followed by up to 10 digits.", "Invalid Cellphone");
            return;
        }

        if (users.containsKey(username)) {
            showError("Username already registered. Please login or choose another username.", "Username Exists");
            return;
        }

        registerUser(username, password, cellphone);
    }

    public boolean registerUser(String username, String password, String cellphone) {
        if (users.containsKey(username)) {
            return false;
        }
        
        users.put(username, new User(username, password, cellphone));
        showSuccess("Registration successful!");
        clearRegistrationFields();
        navigateToLogin();
        return true;
    }

    private void navigateToLogin() {
        dispose();
        new LoginFrame(users).setVisible(true);
    }

    private void showError(String message, String title) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
    }

    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public boolean validateUsername(String username) {
        if (username == null || username.length() > 5) return false;
        return username.contains("_");
    }

    public boolean validatePassword(String password) {
        if (password == null || password.length() < 8) return false;

        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) hasUpper = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else if (!Character.isLetterOrDigit(ch)) hasSpecial = true;
        }

        return hasUpper && hasDigit && hasSpecial;
    }

    public boolean validateCellphone(String cellphone) {
        if (cellphone == null) return false;
        String regex = "^\\+\\d{1,3}\\d{1,10}$";
        return Pattern.matches(regex, cellphone);
    }

    private void clearRegistrationFields() {
        regUsernameField.setText("");
        regPasswordField.setText("");
        regCellphoneField.setText("");
    }
}