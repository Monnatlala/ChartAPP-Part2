package part.pkg1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Complete Unit Test Suite for Message.java
 * Tests all 5 required categories with 100% pass rate
 * @author RC_Student_Lab
 */
public class MessageTest {
    
    // Test data - Message 1
    private static final String RECIPIENT_1 = "+27718693002";
    private static final String MESSAGE_1 = "Hi Mike, can you join us for dinner tonight";
    private static final String ACTION_1 = "send";
    
    // Test data - Message 2
    private static final String RECIPIENT_2 = "08575975889";
    private static final String MESSAGE_2 = "Hi Keegan, did you receive the payment?";
    private static final String ACTION_2 = "discard";
    
    private Message message1;
    private Message message2;
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("=== Starting Message Test Suite ===");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("=== Message Test Suite Complete ===");
    }
    
    @Before
    public void setUp() {
        // Initialize test messages before each test
        message1 = new Message(1, RECIPIENT_1, MESSAGE_1);
        message2 = new Message(2, RECIPIENT_2, MESSAGE_2);
    }
    
    @After
    public void tearDown() {
        message1 = null;
        message2 = null;
    }

    // ========== TEST CATEGORY 1: MESSAGE LENGTH VALIDATION ==========
    
    /**
     * Test 1.1: Valid message length (under 250 characters)
     * Expected: "Message ready to send."
     */
    @Test
    public void testValidMessageLength_Message1() {
        System.out.println("Test 1.1: Valid message length - Message 1");
        String expected = "Message ready to send.";
        String actual = message1.validateMessageLength();
        assertEquals("Message 1 should be ready to send (under 250 chars)", expected, actual);
    }
    
    /**
     * Test 1.2: Valid message length (under 250 characters)
     * Expected: "Message ready to send."
     */
    @Test
    public void testValidMessageLength_Message2() {
        System.out.println("Test 1.2: Valid message length - Message 2");
        String expected = "Message ready to send.";
        String actual = message2.validateMessageLength();
        assertEquals("Message 2 should be ready to send (under 250 chars)", expected, actual);
    }
    
    /**
     * Test 1.3: Invalid message length (exceeds 250 characters)
     * Expected: Error message about exceeding limit
     */
    @Test
    public void testInvalidMessageLength_ExceedsLimit() {
        System.out.println("Test 1.3: Invalid message length - Exceeds 250 characters");
        // Create a message with 251+ characters
        String longMessage = "a".repeat(251);
        Message longMsg = new Message(3, RECIPIENT_1, longMessage);
        
        String expected = "Message exceeds 250 character limit.";
        String actual = longMsg.validateMessageLength();
        assertEquals("Message exceeding 250 chars should return error", expected, actual);
    }
    
    /**
     * Test 1.4: Boundary test - Exactly 250 characters
     * Expected: "Message ready to send."
     */
    @Test
    public void testBoundaryMessageLength_Exactly250() {
        System.out.println("Test 1.4: Boundary test - Exactly 250 characters");
        String boundaryMessage = "a".repeat(250);
        Message boundaryMsg = new Message(4, RECIPIENT_1, boundaryMessage);
        
        String expected = "Message ready to send.";
        String actual = boundaryMsg.validateMessageLength();
        assertEquals("Message with exactly 250 chars should be valid", expected, actual);
    }

    // ========== TEST CATEGORY 2: RECIPIENT PHONE FORMAT VALIDATION ==========
    
    /**
     * Test 2.1: Valid international format (+27718693002)
     * Expected: "Cell phone number successfully captured."
     */
    @Test
    public void testValidRecipientFormat_Message1() {
        System.out.println("Test 2.1: Valid recipient format - Message 1 (+27...)");
        String expected = "Cell phone number successfully captured.";
        String actual = message1.validateRecipientFormat();
        assertEquals("Valid international format should be accepted", expected, actual);
    }
    
    /**
     * Test 2.2: Invalid format - Missing international code (08575975889)
     * Expected: Error message about invalid format
     */
    @Test
    public void testInvalidRecipientFormat_Message2() {
        System.out.println("Test 2.2: Invalid recipient format - Message 2 (no + prefix)");
        String expected = "Invalid cell phone number format.";
        String actual = message2.validateRecipientFormat();
        assertEquals("Format without + should be rejected", expected, actual);
    }
    
    /**
     * Test 2.3: Valid format with different country code
     * Expected: "Cell phone number successfully captured."
     */
    @Test
    public void testValidRecipientFormat_DifferentCountryCode() {
        System.out.println("Test 2.3: Valid recipient format - Different country code");
        Message intlMsg = new Message(5, "+14155552671", "Test message");
        
        String expected = "Cell phone number successfully captured.";
        String actual = intlMsg.validateRecipientFormat();
        assertEquals("Valid US format should be accepted", expected, actual);
    }
    
    /**
     * Test 2.4: Invalid format - Too short
     * Expected: Error message
     */
    @Test
    public void testInvalidRecipientFormat_TooShort() {
        System.out.println("Test 2.4: Invalid recipient format - Too short");
        Message shortMsg = new Message(6, "+123", "Test");
        
        String expected = "Invalid cell phone number format.";
        String actual = shortMsg.validateRecipientFormat();
        assertEquals("Too short number should be rejected", expected, actual);
    }

    // ========== TEST CATEGORY 3: MESSAGE HASH GENERATION ==========
    
    /**
     * Test 3.1: Hash format for Message 1
     * Expected: "Hi:1:TONIGHT"
     */
    @Test
    public void testMessageHashFormat_Message1() {
        System.out.println("Test 3.1: Message hash format - Message 1");
        String expected = "Hi:1:TONIGHT";
        String actual = message1.generateFormattedHash();
        assertEquals("Hash should be FirstWord:Num:LASTWORD format", expected, actual);
    }
    
    /**
     * Test 3.2: Hash format for Message 2
     * Expected: "Hi:2:PAYMENT?"
     */
    @Test
    public void testMessageHashFormat_Message2() {
        System.out.println("Test 3.2: Message hash format - Message 2");
        String expected = "Hi:2:PAYMENT?";
        String actual = message2.generateFormattedHash();
        assertEquals("Hash should be FirstWord:Num:LASTWORD format", expected, actual);
    }
    
    /**
     * Test 3.3: Hash format with single word message
     * Expected: "Hello:7:HELLO"
     */
    @Test
    public void testMessageHashFormat_SingleWord() {
        System.out.println("Test 3.3: Message hash format - Single word");
        Message singleWord = new Message(7, RECIPIENT_1, "Hello");
        
        String expected = "Hello:7:HELLO";
        String actual = singleWord.generateFormattedHash();
        assertEquals("Single word should appear as both first and last", expected, actual);
    }
    
    /**
     * Test 3.4: Verify hash contains correct sequence number
     */
    @Test
    public void testMessageHashContainsSequenceNumber() {
        System.out.println("Test 3.4: Hash contains correct sequence number");
        String hash = message1.generateFormattedHash();
        assertTrue("Hash should contain sequence number 1", hash.contains(":1:"));
        
        String hash2 = message2.generateFormattedHash();
        assertTrue("Hash should contain sequence number 2", hash2.contains(":2:"));
    }

    // ========== TEST CATEGORY 4: MESSAGE ID VALIDATION ==========
    
    /**
     * Test 4.1: Message ID is exactly 10 digits
     */
    @Test
    public void testMessageIDLength() {
        System.out.println("Test 4.1: Message ID length validation");
        String msgID1 = message1.getMessageID();
        assertEquals("Message ID should be 10 digits", 10, msgID1.length());
        
        String msgID2 = message2.getMessageID();
        assertEquals("Message ID should be 10 digits", 10, msgID2.length());
    }
    
    /**
     * Test 4.2: Message ID contains only numeric characters
     */
    @Test
    public void testMessageIDNumericOnly() {
        System.out.println("Test 4.2: Message ID numeric validation");
        String msgID1 = message1.getMessageID();
        assertTrue("Message ID should contain only digits", msgID1.matches("\\d{10}"));
        
        String msgID2 = message2.getMessageID();
        assertTrue("Message ID should contain only digits", msgID2.matches("\\d{10}"));
    }
    
    /**
     * Test 4.3: Message IDs are unique
     */
    @Test
    public void testMessageIDUniqueness() {
        System.out.println("Test 4.3: Message ID uniqueness");
        String msgID1 = message1.getMessageID();
        String msgID2 = message2.getMessageID();
        assertNotEquals("Message IDs should be unique", msgID1, msgID2);
    }
    
    /**
     * Test 4.4: checkMessageID() returns true for valid IDs
     */
    @Test
    public void testCheckMessageIDValidation() {
        System.out.println("Test 4.4: checkMessageID() validation method");
        assertTrue("checkMessageID should return true for valid ID", message1.checkMessageID());
        assertTrue("checkMessageID should return true for valid ID", message2.checkMessageID());
    }

    // ========== TEST CATEGORY 5: MESSAGE ACTIONS ==========
    
    /**
     * Test 5.1: Send action for Message 1
     * Expected: "Message successfully sent."
     */
    @Test
    public void testMessageAction_Send() {
        System.out.println("Test 5.1: Message action - Send");
        String expected = "Message successfully sent.";
        String actual = message1.processMessageAction(ACTION_1);
        assertEquals("Send action should return success message", expected, actual);
    }
    
    /**
     * Test 5.2: Discard action for Message 2
     * Expected: "Press 0 to delete message."
     */
    @Test
    public void testMessageAction_Discard() {
        System.out.println("Test 5.2: Message action - Discard");
        String expected = "Press 0 to delete message.";
        String actual = message2.processMessageAction(ACTION_2);
        assertEquals("Discard action should return delete prompt", expected, actual);
    }
    
    /**
     * Test 5.3: Store action
     * Expected: "Message successfully stored."
     */
    @Test
    public void testMessageAction_Store() {
        System.out.println("Test 5.3: Message action - Store");
        String expected = "Message successfully stored.";
        String actual = message1.processMessageAction("store");
        assertEquals("Store action should return stored message", expected, actual);
    }
    
    /**
     * Test 5.4: Invalid/null action
     * Expected: "Press 0 to delete message."
     */
    @Test
    public void testMessageAction_Null() {
        System.out.println("Test 5.4: Message action - Null/Invalid");
        String expected = "Press 0 to delete message.";
        String actual = message1.processMessageAction(null);
        assertEquals("Null action should default to delete prompt", expected, actual);
    }
    
    /**
     * Test 5.5: Case insensitivity of actions
     */
    @Test
    public void testMessageAction_CaseInsensitive() {
        System.out.println("Test 5.5: Message action - Case insensitivity");
        assertEquals("SEND should work", "Message successfully sent.", 
                     message1.processMessageAction("SEND"));
        assertEquals("Send should work", "Message successfully sent.", 
                     message1.processMessageAction("Send"));
        assertEquals("store should work", "Message successfully stored.", 
                     message1.processMessageAction("store"));
    }

    // ========== INTEGRATION TESTS ==========
    
    /**
     * Integration Test 1: Complete message lifecycle for Message 1
     */
    @Test
    public void testCompleteMessageLifecycle_Message1() {
        System.out.println("Integration Test 1: Complete Message 1 lifecycle");
        
        // Validate all components
        assertEquals("Message ready to send.", message1.validateMessageLength());
        assertEquals("Cell phone number successfully captured.", message1.validateRecipientFormat());
        assertEquals("Hi:1:TONIGHT", message1.generateFormattedHash());
        assertEquals(10, message1.getMessageID().length());
        assertEquals("Message successfully sent.", message1.processMessageAction(ACTION_1));
    }
    
    /**
     * Integration Test 2: Complete message lifecycle for Message 2
     */
    @Test
    public void testCompleteMessageLifecycle_Message2() {
        System.out.println("Integration Test 2: Complete Message 2 lifecycle");
        
        // Validate all components
        assertEquals("Message ready to send.", message2.validateMessageLength());
        assertEquals("Invalid cell phone number format.", message2.validateRecipientFormat());
        assertEquals("Hi:2:PAYMENT?", message2.generateFormattedHash());
        assertEquals(10, message2.getMessageID().length());
        assertEquals("Press 0 to delete message.", message2.processMessageAction(ACTION_2));
    }
    
    /**
     * Test getter methods for completeness
     */
    @Test
    public void testGetterMethods() {
        System.out.println("Test: Getter methods validation");
        
        assertEquals(RECIPIENT_1, message1.getRecipient());
        assertEquals(MESSAGE_1, message1.getMessageText());
        assertEquals(1, message1.getSeqNum());
        assertNotNull(message1.getMessageHash());
        
        assertEquals(RECIPIENT_2, message2.getRecipient());
        assertEquals(MESSAGE_2, message2.getMessageText());
        assertEquals(2, message2.getSeqNum());
        assertNotNull(message2.getMessageHash());
    }
}