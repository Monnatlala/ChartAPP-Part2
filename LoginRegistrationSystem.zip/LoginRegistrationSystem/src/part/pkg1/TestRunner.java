package part.pkg1;

import com.sun.net.httpserver.Authenticator.Failure;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;


public class TestRunner {
    public static void main(String[] args) {
        Result result = JUnitCore.runClasses(LoginRegistrationTest.class);
        
        System.out.println("=== TEST RESULTS ===");
        System.out.println("Total tests run: " + result.getRunCount());
        System.out.println("Failed tests: " + result.getFailureCount());
        System.out.println("Ignored tests: " + result.getIgnoreCount());
        System.out.println("Execution time: " + result.getRunTime() + "ms");
        System.out.println("====================");
        
        if (result.wasSuccessful()) {
            System.out.println("🎉 ALL TESTS PASSED! 🎉");
        } else {
            System.out.println("\n❌ FAILED TESTS:");
            
        }
        
        System.out.println("Success rate: " + 
            String.format("%.1f%%", (result.getRunCount() - result.getFailureCount()) * 100.0 / result.getRunCount()));
    }
}