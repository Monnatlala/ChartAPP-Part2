/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg1;

/**
 *
 * @author RC_Student_Lab
 */
  /*
 Message.java
 Defines a Message class for the QuickChat application.
 Handles validation, ID generation, and message hashing.
*/

 import javax.swing.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class Message {
    private String messageID;       // 10-digit random ID
    private int seqNum;             // Sequential message number
    private String recipient;       // Cell number (+27...)
    private String messageText;     // Text message
    private String messageHash;     // SHA-256 hash of message text

    // Constructor
    public Message(int seqNum, String recipient, String messageText) {
        this.seqNum = seqNum;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = computeHash(messageText);
    }

    // Generate a random 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        long num = 1000000000L + (long)(rand.nextDouble() * 8999999999L);
        return String.valueOf(num);
    }

    // Validate Message ID (should be 10 digits)
    public boolean checkMessageID() {
        return messageID != null && messageID.length() == 10 && messageID.matches("\\d+");
    }

    // Validate recipient cell number
    // Returns 1 if valid, 0 if invalid
    public int checkRecipientCell() {
        if (recipient == null) return 0;
        // Must start with + and have 11–15 digits
        if (recipient.matches("\\+\\d{11,15}")) {
            return 1;
        }
        return 0;
    }

    // Compute SHA-256 hash of the message text
    private String computeHash(String text) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(text.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return "HASH_ERROR";
        }
    }

    // Get message hash
    public String getMessageHash() {
        return messageHash;
    }

    // Ask user what to do with message
    public String sentMessage() {
        String[] options = {"Send", "Store", "Discard"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "What would you like to do with this message?\n\n"
                        + "Recipient: " + recipient + "\nMessage: " + messageText,
                "Message Options",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );

        switch (choice) {
            case 0: return "send";
            case 1: return "store";
            default: return "discard";
        }
    }

    // String representation for display
    @Override
    public String toString() {
        return "Message #" + seqNum + "\n"
                + "ID: " + messageID + "\n"
                + "Recipient: " + recipient + "\n"
                + "Text: " + messageText + "\n"
                + "Hash: " + messageHash + "\n";
    }

    public Object printFullDetails() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
 