package part.pkg1;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.HashMap;

public class LoginRegistrationTest {
    
    @Test
    public void testBasicValidation() {
        RegistrationFrame frame = new RegistrationFrame(new HashMap<>());
        assertTrue("Valid username should pass", frame.validateUsername("test_"));
        assertFalse("Invalid username should fail", frame.validateUsername("test1"));
    }
    
    @Test
    public void testPasswordValidation() {
        RegistrationFrame frame = new RegistrationFrame(new HashMap<>());
        assertTrue("Valid password should pass", frame.validatePassword("Test123!"));
        assertFalse("Invalid password should fail", frame.validatePassword("weak"));
    }
}